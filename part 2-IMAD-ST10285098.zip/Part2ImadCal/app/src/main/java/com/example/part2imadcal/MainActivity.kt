package com.example.part2imadcal

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {
    private lateinit var num1EditTextView: EditText
    private lateinit var num2EditText: EditText
    private lateinit var resultTextView: TextView
    private lateinit var buttonAdd: Button
    private lateinit var buttonSubtract: Button
    private lateinit var buttonMultiply: Button
    private lateinit var buttonDivide: Button
    private lateinit var buttonSquareRoot: Button
    private lateinit var buttonPower: Button
    private lateinit var buttonClear: Button

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize UI components
        num1EditTextView = findViewById(R.id.num1editTextNumber)
        num2EditText = findViewById(R.id.num2editTextNumber)
        resultTextView = findViewById(R.id.editTextNumber)
        buttonAdd = findViewById(R.id.buttonAdd)
        buttonSubtract = findViewById(R.id.buttonSubtract)
        buttonMultiply = findViewById(R.id.buttonMultiply)
        buttonDivide = findViewById(R.id.buttonDivide)
        buttonSquareRoot = findViewById(R.id.buttonSquareRoot)
        buttonPower = findViewById(R.id.buttonPower)
        buttonClear = findViewById(R.id.buttonClear)

        // Set click listeners for operation buttons
        buttonAdd.setOnClickListener { performOperation(Operation.ADD) }
        buttonSubtract.setOnClickListener { performOperation(Operation.SUBTRACT) }
        buttonMultiply.setOnClickListener { performOperation(Operation.MULTIPLY) }
        buttonDivide.setOnClickListener { performOperation(Operation.DIVIDE) }
        buttonSquareRoot.setOnClickListener { performOperation(Operation.SQUARE_ROOT) }
        buttonPower.setOnClickListener { performOperation(Operation.POWER) }

        // Set click listener for clear button
        buttonClear.setOnClickListener {
            num1EditTextView.text.clear()
            num2EditText.text.clear()
            resultTextView.text = ""
            Toast.makeText(this, "Cleared", Toast.LENGTH_LONG).show()
        }
    }

    private fun performOperation(operation: Operation) {
        val num1Text = num1EditTextView.text.toString()
        val num2Text = num2EditText.text.toString()

        if (num1Text.isNotBlank() && num2Text.isNotBlank()) {
            val num1 = num1Text.toInt()
            val num2 = num2Text.toInt()

            val result = when (operation) {
                Operation.ADD -> num1 + num2
                Operation.SUBTRACT -> num1 - num2
                Operation.MULTIPLY -> num1 * num2
                Operation.DIVIDE -> if (num2 != 0) num1.toDouble() / num2.toDouble() else Double.NaN
                Operation.SQUARE_ROOT -> if (num1 >= 0) sqrt(num1.toDouble()) else sqrt(abs(num1).toDouble()) * 1i
                        Operation.POWER -> num1.toDouble().pow(num2)
            }

            if (!result.isNaN()) {
                resultTextView.text = "Result: $result"
            } else {
                resultTextView.text = "Error: Division by 0 is not allowed"
            }
        } else {
            Toast.makeText(this, "Please enter both numbers", Toast.LENGTH_SHORT).show()
        }
    }

    // Imaginary unit representation
    private val 1i = "i"
}

enum class Operation {
    ADD,
    SUBTRACT,
    MULTIPLY,
    DIVIDE,
    SQUARE_ROOT,
    POWER
}
